### More details https://akveo.github.io/nebular/

### This package is deprecated. We suggest using native Nebular components instead.

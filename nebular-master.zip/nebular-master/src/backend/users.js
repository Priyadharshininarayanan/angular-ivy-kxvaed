/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */

const users = [
  {
    id: 1,
    name: 'John Doe',
    email: 'example@akveo.com',
    password: '123456'
  }
];

module.exports = users;

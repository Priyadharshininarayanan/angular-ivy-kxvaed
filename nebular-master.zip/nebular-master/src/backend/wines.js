const wines = [
  {
    id: 1,
    name: 'Pommard 1er cru',
    region: 'Bourgogne',
    year: 2012,
  },
  {
    id: 2,
    name: 'Aloxe Corton Grand cru',
    region: 'Bourgogne',
    year: 2008,
  },
  {
    id: 3,
    name: 'Meursault 1er cru',
    region: 'Bourgogne',
    year: 1997,
  },
];

module.exports = wines;

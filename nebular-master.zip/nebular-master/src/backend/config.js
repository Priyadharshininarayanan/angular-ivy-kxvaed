/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */

module.exports = {
  jwtSecret: 'MyS3cr3tK3Y',
  jwtSession: {
    session: false
  },
  accessTokenExpiresIn : 60,
  refreshTokenExpiresIn: 120
};

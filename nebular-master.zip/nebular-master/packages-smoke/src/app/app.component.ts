import { Component } from '@angular/core';

@Component({
  selector: 'bs-root',
  template: 'Nebular Works!!!',
})
export class AppComponent {
}

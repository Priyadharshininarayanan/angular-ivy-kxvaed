/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */

/* SystemJS module definition */
declare var module: {
  id: string;
};
declare var require: any;
declare var structure: any;
declare var docs: any;

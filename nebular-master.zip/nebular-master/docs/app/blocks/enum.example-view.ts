export enum NgdExampleView {
  LIVE = 'live',
  INLINE = 'inline',
}

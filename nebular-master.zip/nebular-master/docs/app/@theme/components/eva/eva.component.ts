import { Component } from '@angular/core';

@Component({
  selector: 'ngd-eva',
  styleUrls: ['./eva.components.scss'],
  templateUrl: './eva.component.html',
})
export class NgdEvaComponent {}

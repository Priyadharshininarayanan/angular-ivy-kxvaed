module.exports = process.env.BROWSER_STACK_KEY.split('').reverse().join('');

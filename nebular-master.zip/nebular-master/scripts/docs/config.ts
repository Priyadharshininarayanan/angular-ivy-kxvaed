export const REPO_URL = 'https://github.com/akveo/nebular.git';
export const REPO_OWNER = 'akveo';
export const REPO_NAME = 'nebular';
export const OUT_DIR = 'docs/dist'; // Relative to the directory you run command
